debug_mode = False
host = '0.0.0.0'
port = 8080

# importing `local_config` from `config`
if __name__ == 'config':
    try:
        from local_config import *
    except ModuleNotFoundError:
        propt_str = 'Please create a `local_config.py` from `config.py`, then restart the web server.'
        len_str = len(propt_str)
        print("!" * len_str)
        print(propt_str)
        print("!" * len_str)
        exit(1)