from flask import Flask
from config import debug_mode, host, port

app = Flask(__name__)

# import all necessary views here
from user.views import *
from admin.views import *
from group.views import *
from weekly_publication.views import *
if __name__ == "__main__":
    db.create_all()
    app.run(debug=debug_mode, host=host, port=port)

