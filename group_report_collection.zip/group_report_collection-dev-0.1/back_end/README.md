# Dian 团队质量组简报收取项目 后端部署文档

Work Path：`$project_path/back_end/`

## 环境准备

首先，安装 `python3`、`pip3` 与 `sqlite`:

```shell
sudo apt install sqlite python3 python3-pip
```

然后，为了避免与系统python包版本冲突，使用 `virtualenv` 构建本地python包环境。安装 `virtualenv`:

```shell
sudo apt install virtualenv virtualenvwrapper
```

然后运行 `virtualenvwrapper.sh`

```shell
source /usr/share/virtualenvwrapper/virtualenvwrapper.sh
```

指定使用 `python3` 版本创建虚拟环境

```shell
mkvirtualenv -p /usr/bin/python3 group_report_collection
```

使用 `deactivate` 退出虚拟环境，`workon [env_name]` 重新进入虚拟环境。

之后，使用 `pip` 安装所有必须依赖：

```shell
pip3 install -r requirements.txt
```

并复制`config.py`为`local_config.py`

```shell
cp config.py local_config.py
```

使用`python main.py`启动服务器即可。