from flask import request
from config import FilePath

# 图片存储目录（部署服务器时更改路径）
basedir = FilePath.img_basedir


# 字节流转图片
def save_img(name):
    # 通过表单中 'avatars' 值获取图片
    imgData = request.files["avatars"]

    # 格式化图片储存名字
    file_path = basedir + name + ".png"
    imgData.save(file_path)

    return file_path


def get_img_url(name):
    return basedir.split('.')[1] + name + ".png"
