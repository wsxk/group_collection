from flask import request, jsonify

from main import app
from model import db, User, Group
from jwt_utils.jwt import create_token, verify_token
from user.img import save_img, get_img_url
from config import SuperAdmin

import time
import json


@app.route('/api/account/register', methods=["POST"])
def register():
    get_data = json.loads(request.form.get('info'))  # 获取表单中的 'info' json文件

    name = get_data.get('name')
    account = get_data.get('account')
    password = get_data.get('password')
    email = get_data.get('email')
    qq_number = get_data.get('qq_number')
    group_id = get_data.get('group')

    if not Group.query.filter_by(id=group_id).first():
        return jsonify(code=-2, msg="项目组不存在，请联系管理员添加！")
    if not User.query.filter_by(account=account).first():
        # 用户名不存在，开始保存图片
        save_img(account)
        user = User(account=account, password=password, name=name,
                    group_id=group_id, email=email, qq_number=qq_number, is_enable=True)
        db.session.add(user)
        db.session.commit()
    else:
        return jsonify(code=-1, msg="用户名已存在")

    return jsonify(code=0, msg="注册成功")


@app.route('/api/account/login', methods=["POST"])
def login():
    get_data = request.get_json()
    account = get_data.get('account')
    password = get_data.get('password')

    user = User.query.filter_by(account=account).first()

    if not account:
        return jsonify(code=-2, msg="用户名为空")
    elif not password:
        return jsonify(code=-3, msg="密码为空")
    # 数据库中未查询到该用户
    elif not user:
        return jsonify(code=-1, msg="用户名或密码错误")
    # 数据库中查询到该用户且密码正确
    elif user.password == password:
        account_ = {
            'account': account
        }
        invalid_time_ = {
            "typ": "jwt_utils",  # token类型
            'invalid_time': '%lf' % (time.time() + 3600)
        }

        token = create_token(account_, invalid_time_, '648648')
        return jsonify(code=0, msg="登录成功", token=token)
    else:
        return jsonify(code=-1, msg="用户名或密码错误")


@app.route('/api/account/accountInfo', methods=["POST"])
def certify_current_user():
    get_data = request.get_json()
    token = get_data.get('token')

    account = verify_token(token, '648648')
    if account == -1:
        return jsonify(code=-1, msg="无效的token")
    elif account == -2:
        return jsonify(code=-2, msg="token已过期")
    elif account == SuperAdmin.account:
        return jsonify(code=0, msg="获取成功", name=SuperAdmin.account)
    else:
        user = User.query.filter_by(account=account).first()
        if not user:
            return jsonify(code=-3, msg="token对应用户名不存在")
        else:
            name = user.name
            email = user.email
            group_name = Group.query.filter_by(id=user.group_id).first().name
            avatars = get_img_url(account)
            qq_number = user.qq_number
            return jsonify(code=0, msg="获取成功", name=name, group=group_name, email=email,
                           avatars=avatars, qq_number=qq_number)


@app.route('/api/account/infoChange', methods=["POST"])
def change_user_info():
    get_data = json.loads(request.form.get('info'))  # 获取表单中的 'info' json文件
    token = get_data.get('token')
    account = get_data.get('account')
    password = get_data.get('password')
    name = get_data.get('name')
    group_id = get_data.get('group')
    email = get_data.get('email')
    qq_number = get_data.get('qq_number')
    is_enable = get_data.get('enable')
    is_avatars_changed = get_data.get('avatars_changed')

    # 验证token，并确认 token 身份信息
    token_account = verify_token(token, '648648')
    if token_account == -1:
        return jsonify(code=-1, msg="无效的token")
    elif token_account == -2:
        return jsonify(code=-2, msg="token已过期")
    elif token_account == SuperAdmin.account:
        pass
    else:
        account = token_account

    user = User.query.filter_by(account=account).first()
    group = Group.query.filter_by(id=group_id).first()
    print(group)
    if not group:
        return jsonify(code=-3, msg="所要修改的对应项目组不存在，请联系管理员添加")

    if not user:
        return jsonify(code=-4, msg="用户不存在")
    else:
        User.query.filter(User.account == account).update({
            "name": name,
            "password": password,
            "email": email,
            "qq_number": qq_number,
            "group_id": group_id,
            "is_enable": is_enable
        })
        db.session.commit()

        if is_avatars_changed:
            save_img(account)

        return jsonify(code=0, msg="修改成功")
