import time
import base64
import hmac
import json
import hashlib


# 生成token
def create_token(account, invalid_time, salt):
    # token头部
    headers = base64.urlsafe_b64encode(
        json.dumps(invalid_time, separators=(',', ':')).encode('utf-8').replace(b'=', b'')).decode(
        'utf-8').replace('=', '')
    # token数据
    payload = base64.urlsafe_b64encode(
        json.dumps(account, separators=(',', ':')).encode('utf-8').replace(b'=', b'')).decode(
        'utf-8').replace('=', '')
    # 拼接前两部分
    headers_payload = f"{headers}.{payload}"
    # 对前面两部分签名
    sign = base64.urlsafe_b64encode(
        hmac.new(salt.encode('utf-8'), headers_payload.encode('utf-8'), hashlib.sha256).digest()).decode(
        'utf-8').replace('=', '')

    # 拼接签名和前两部分，token生成完成
    token = ".".join([headers, payload, sign])
    return token


# 解析token
def verify_token(token, salt):
    # 提取出header、payload、sign
    headers = token.split(".")[0]
    payload = token.split(".")[1]
    sign = token.split(".")[2]

    headers_payload = f"{headers}.{payload}"

    new_sign = base64.urlsafe_b64encode(
        hmac.new(salt.encode('utf-8'), headers_payload.encode('utf-8'), hashlib.sha256).digest()).decode(
        'utf-8').replace('=', '')
    # 判断签名是否相等
    if new_sign != sign:
        return -1  # 无效的token

    # 验证token是否过期
    if isinstance(headers, str):
        headers = headers.encode('ascii')

    rem = len(headers) % 4
    if rem > 0:
        headers += b'=' * (4 - rem)
    # 上面这一部分是解密的部分数据补全格式
    headers_data = base64.urlsafe_b64decode(headers)  # 解码
    data = json.loads(headers_data)  # 加载headers信息为可以通过get方法获取里面的值
    invalid_time = data.get('invalid_time')
    if float(invalid_time) < time.time():
        return -2  # token已过期

    # 获取用户名
    if isinstance(payload, str):
        payload = payload.encode('ascii')

    rem = len(payload) % 4
    if rem > 0:
        payload += b'=' * (4 - rem)
    # 上面这一部分是解密的部分数据补全格式
    payload_data = base64.urlsafe_b64decode(payload)  # 解码
    data = json.loads(payload_data)  # 加载payload信息为可以通过get方法获取里面的值
    account = data.get('account')
    return account