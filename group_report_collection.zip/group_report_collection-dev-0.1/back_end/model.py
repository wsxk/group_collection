from flask_sqlalchemy import SQLAlchemy
# from passlib.apps import custom_app_context as pwd_context

from main import app

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + "model.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "diangroup"

db = SQLAlchemy(app)  # 实例化的数据库


# 周报收取周期
class ReceivePeriod(db.Model):
    __tablename__ = 'period'
    id = db.Column(db.Integer, primary_key=True, nullable=False)        # ID(主键)
    begin_time = db.Column(db.String(16), nullable=False)               # 开始时间
    end_time = db.Column(db.String(16), nullable=False)                 # 结束时间
    check_time = db.Column(db.String(100))                              # 检查时间
    title = db.Column(db.String(30))                                    # 标题
    member_id = db.Column(db.Integer)                                   # 负责人
    store_order = db.Column(db.String(300))                             # 存储顺序
    submit_status = db.Column(db.String(100))                           # 提交状态
    directory = db.Column(db.String(30))                                # FTP存储目录
    is_active = db.Column(db.Boolean, nullable=False)                   # 是否激活(超时后数据库强制disable)


# 质量组成员名单
class Member(db.Model):
    __tablename__ = 'member'
    id = db.Column(db.Integer, primary_key=True)                        # ID(主键)
    name = db.Column(db.String(16), nullable=False)                     # 姓名
    qq_number = db.Column(db.String(16), unique=True, nullable=False)   # QQ
    email = db.Column(db.String(64), unique=True, nullable=False)       # 邮箱
    is_enable = db.Column(db.Boolean, nullable=False)                   # 是否有效


# 项目组组长
class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)                        # ID(主键)
    name = db.Column(db.String(16), nullable=False)                     # 项目组组长名
    account = db.Column(db.String(64), unique=True, nullable=False)     # 用户名
    password = db.Column(db.String(64), nullable=False)                 # 密码
    email = db.Column(db.String(64), nullable=False)                    # 提醒邮箱
    qq_number = db.Column(db.String(16), nullable=False)                # QQ
    group_id = db.Column(db.Integer)                                    # 所属项目组ID
    is_enable = db.Column(db.Boolean, nullable=False)                   # 是否有效
    

# 项目组
class Group(db.Model):
    __tablename__ = 'group'
    id = db.Column(db.Integer, primary_key=True)                        # ID(主键)
    name = db.Column(db.String(16), unique=True, nullable=False)        # 项目组名
    is_enable = db.Column(db.Boolean, nullable=False)                   # 是否有效