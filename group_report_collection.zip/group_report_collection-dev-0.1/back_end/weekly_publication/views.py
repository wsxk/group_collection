from operator import index
from time import time
from main import app
from model import db, ReceivePeriod, Member, User, Group
from flask import request, jsonify, send_from_directory
from jwt_utils.jwt import verify_token
from sqlalchemy import desc
import json
from config import FilePath
import os


# 添加收取任务
@app.route('/api/report/beginCollection', methods=['POST'])
def begin_collection():
    get_data = request.get_json()
    begin_time = get_data.get('begin_time')
    end_time = get_data.get('end_time')
    title = get_data.get('title')
    director = get_data.get('director')
    check_time = get_data.get('check_time')     # check_time为数组，转换成string
    check_time = json.dumps(check_time)
    store_order = get_data.get('group_order')   
    #判断项目组是否存在
    for group in store_order:
        if not Group.query.filter_by(id=group).first():
            return jsonify(code=-2, msg="有一个或多个项目组ID不存在")
    length = len(store_order)
    # store_order为数组，转换成string
    store_order = json.dumps(store_order)
    ftp_path = get_data.get('ftp_path')
    director_id = Member.query.filter_by(id=director).first()           # 根据该id查询是否存在该人
    if_receive = ReceivePeriod.query.filter_by(begin_time=begin_time).first()
    if if_receive:                                      # 判断周报是否已经存在
        return jsonify(code=-1, msg="任务已存在")
    
    if director_id:                 # 判断负责人是否存在
        submit_status = []
        for i in range(length):
            submit_status.append(0)
        submit_status = json.dumps(submit_status)
        receive_period = ReceivePeriod(begin_time=begin_time, end_time=end_time, title=title, member_id=director, check_time=check_time, directory=ftp_path, store_order=store_order, is_active=0, submit_status=submit_status)
        db.session.add(receive_period)
        db.session.commit()
        return jsonify(code=0, msg="添加成功")
    else:
        return jsonify(code=-3, msg="负责人不存在")


# 激活收取任务
@app.route('/api/report/activateCollection', methods=['POST'])
def activate_collection():
    get_data = request.get_json()
    begin_time = get_data.get('begin_time')
    receive = ReceivePeriod.query.filter_by(begin_time=begin_time).first()
    if not receive:
        return jsonify(code=-1, msg="未找到该任务")
    receive.update({
        "is_active": True
    })
    # db.session.add(receive) # 添加时就已添加
    db.session.commit()
    return jsonify(code=0, msg="激活成功")


# 修改收取任务
@app.route('/api/report/modifyCollection', methods=['POST'])
def modify_collection():
    get_data = request.get_json()
    begin_time = get_data.get('begin_time')
    end_time = get_data.get('end_time')
    title = get_data.get('title')
    director = get_data.get('director')
    check_time = get_data.get('check_time')
    check_time_json = json.dumps(check_time)
    group_order = get_data.get('group_order')
    #判断项目组是否存在
    for group in group_order:
        if not Group.query.filter_by(id=group).first():
            return jsonify(code=-2, msg="有一个或多个项目组ID不存在")
    group_order_json = json.dumps(group_order)
    ftp_path = get_data.get('ftp_path')

    director_id = Member.query.filter_by(id=director).first()           # 查询该人是否存在
    receive_period = ReceivePeriod.query.filter_by(begin_time=begin_time).first()
    if not receive_period:
        return jsonify(code=-1, msg="收取任务不存在")
    if not director_id:
        return jsonify(code=-3, msg="负责人不存在")
    # 判断 store_order 是否有修改
    if receive_period.store_order == group_order_json:
        # begintime 不可修改，且group_order未变化，说明不需要更改submit_status
        receive_period.update({
            "end_time": end_time,
            "title": title,
            "member_id": director,
            "check_time": check_time_json,
            "directory": ftp_path
        })
    else:
        # store_order有修改，需要对应修改 submit_status
        old_store_order = json.loads(receive_period.store_order)
        old_submit_status = json.loads(receive_period.submit_status)
        new_submit_status = []
        for element in group_order:
            new_submit_status.append(old_submit_status[old_store_order.index(element)])
        receive_period.update({
            "end_time": end_time,
            "title": title,
            "member_id": director,
            "check_time": check_time_json,
            "directory": ftp_path,
            "store_order": group_order_json,
            "submit_status": new_submit_status
        })
    # db.session.add(receive_period)
    db.session.commit()
    return jsonify(code=0, msg='修改成功')


# 获取收取任务列表
@app.route('/api/report/collectionList', methods=['POST'])
def collection_list():
    get_data = request.get_json()

    time_period = get_data.get('time_period')
    if not time_period:
        collect_list = ReceivePeriod.query.order_by(desc(ReceivePeriod.begin_time)).limit(10)
    else:
        time_period_begin, time_period_end = time_period.split('-')
        time_period_begin += "000000"
        time_period_end += "235959"
        collect_list = ReceivePeriod.query.filter(ReceivePeriod.begin_time.between(time_period_begin,time_period_end)).order_by(desc(ReceivePeriod.begin_time)).all()
    tasks = []
    for each in collect_list:
       info = {
            "begin_time": each.begin_time,
            "end_time": each.end_time,
            "title": each.title,
            "director": each.member_id,
            "check_time": each.check_time,
            "group_order": each.store_order,
            "ftp_path": each.directory,
            "enable": each.is_active,
       }
       tasks.append(info)
    if tasks:
        return jsonify(code=0, msg="获取成功", tasks=tasks)
    else:
        return jsonify(code=-1, msg="在该时间段内未找到有效收取周期记录")


# 查询状态
@app.route('/api/report/submitStatus', methods=['POST'])
def report_submit_status():
    get_data = request.get_json()
    begin_time = get_data.get('begin_time')
    token = get_data.get('token')
    result = verify_token(token, '648648')
    if result == -1:
        return jsonify(code=-2, msg="无效的token")
    if result == -2:
        return jsonify(code=-3, msg="token已过期")
    receive_record = ReceivePeriod.query.filter_by(begin_time=begin_time).first()
    if not receive_record:
        return jsonify(code=-1, msg="未查询到该收取任务记录")

    group_id = User.query.filter_by(account=result).first().group_id
    store_order = json.loads(receive_record.store_order)
    submit_status = json.loads(receive_record.submit_status)
    try:
        return jsonify(code=0, submitted=bool(submit_status[store_order.index(group_id)]))
    except:
        return jsonify(code=-4, msg='该用户所属组不存在，查询失败')


# 上传ppt
@app.route('/api/report/uploadReport', methods=['POST'])
def upload_report():
    get_data = json.loads(request.form.get('info'))         # 获取表单中的 'info' json文件
    begin_time = get_data.get('begin_time')
    token = get_data.get('token')
    result = verify_token(token, '648648')
    if result == -1:
        return jsonify(code=-2, msg='无效的token')
    if result == -2:
        return jsonify(code=-3, msg='token已过期')
    receive_record = ReceivePeriod.query.filter_by(begin_time=begin_time)
    if not receive_record:
        return jsonify(code=-1, msg='未查询到该收取任务记录')

    user = User.query.filter_by(account=result).first()
    group_name = Group.query.filter_by(id=user.group_id).first().name
    # 提交ppt文件
    ppt_data = request.files['ppt']
    dir_path = FilePath.ppt_basedir
    dir_path += begin_time
    if not os.path.isdir(dir_path):     # 没有目录 要创建目录
        os.mkdir(dir_path)
    file_path = dir_path+'/'+group_name+'.pptx'
    ppt_data.save(file_path)                # 待测试，据说上传同名文件会直接覆盖
    # todo 进行PPT合并工作
    return jsonify(code=0, msg='上传成功!')


# 下载ppt
@app.route('/api/report/downloadReport', methods=['GET'])
def download_report():
    get_data = request.args
    token = get_data.get('token')
    begin_time = get_data.get('begin_time')
    name = get_data.get('name')
    result = verify_token(token, '648648')
    if result == -1:
        return jsonify(code=-2, msg='无效的token')
    if result == -2:
        return jsonify(code=-3, msg='token已过期')
    receive_record = ReceivePeriod.query.filter_by(begin_time=begin_time)
    if not receive_record:
        return jsonify(code=-4, msg='错误的时间，找不到提交报告')
    path = FilePath.ppt_basedir + begin_time
    if not os.path.exists(path):
        return jsonify(code=-5, msg='文件路径不存在')
    if not os.path.isfile(path):
        return jsonify(code=-1, msg='该路径不是文件')
    return send_from_directory(path, name+'.pptx', as_attachment=True)
