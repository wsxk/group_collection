from flask import request, jsonify

from main import app
from model import db, Group

@app.route('/api/group/groupInfo', methods=["POST"])
def get_groups():
    get_data = request.get_json()
    enable = get_data.get('enable')

    groups = Group.query.filter_by(is_enable=enable).all()
    group_dict = {}
    for group in groups:
        group_dict[group.name] = group.id
    return jsonify(code=0, msg="获取成功", group_dict=group_dict)
    

@app.route('/api/group/groupAdd', methods=["POST"])
def add_group():
    get_data = request.get_json()
    group_name = get_data.get('group_name')

    group = Group(name=group_name, is_enable=True)
    db.session.add(group)
    db.session.commit()
    return jsonify(code=0, msg="添加成功")


@app.route('/api/group/groupStatusChange', methods=["POST"])
def disable_group():
    get_data = request.get_json()
    group_id = get_data.get('group_id')
    enable = get_data.get('enable')

    group = Group.query.filter_by(id=group_id)
    if not group.first():
        return jsonify(code=-1, msg="该项目组不存在")
    group.update({
        "is_enable": enable
    })
    db.session.commit()
    return jsonify(code=0, msg="修改成功")
