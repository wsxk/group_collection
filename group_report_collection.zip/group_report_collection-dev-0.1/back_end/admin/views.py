import json
from flask import request, jsonify

from main import app
from model import db, User, Group, Member
from user.img import get_img_url
from jwt_utils.jwt import create_token, verify_token
from admin.super_admin import is_super_admin
from config import SuperAdmin

import time



@app.route('/api/account/adminAdd', methods=["POST"])
def admin_add():
    get_data = request.get_json()

    token = get_data.get('token')
    name = get_data.get('name')
    email = get_data.get('email')
    qq_number = get_data.get('qq_number')
    # 验证token
    verify_result = verify_token(token, '648648')
    if verify_result == -1:
        return jsonify(code=-1, msg="无效的token")
    elif verify_result == -2:
        return jsonify(code=-2, msg="token已过期")
    elif verify_result != SuperAdmin.account:
        return jsonify(code=-3, msg="权限不足")
    # 查询是否有重复
    member = Member.query.filter_by(qq_number=qq_number).first()
    if not member:
        # 为空，增加新成员
        admin = Member(name=name, email=email, qq_number=qq_number, is_enable=True)
        db.session.add(admin)
        db.session.commit()
    else:
        return jsonify(code=-4, msg="质量组成员已存在")

    return jsonify(code=0, msg="添加成功")


@app.route('/api/account/adminLogin', methods=["POST"])
def admin_login():
    get_data = request.get_json()
    account = get_data.get('account')
    password = get_data.get('password')

    if not account:
        return jsonify(code=-2, msg="用户名为空")
    elif not password:
        return jsonify(code=-3, msg="密码为空")
    elif account != SuperAdmin.account or password != SuperAdmin.password:
        return jsonify(code=-1, msg="用户名或密码错误")
    # 用户名且密码均正确
    else:
        account_ = {
            'account': account
        }
        invalid_time_ = {
            "typ": "jwt_utils",  # token类型
            'invalid_time': '%lf' % (time.time() + 3600)
        }

        token = create_token(account_, invalid_time_, '648648')
        return jsonify(code=0, msg="登录成功", token=token)


@app.route('/api/account/accounts', methods=["POST"])
def get_users():
    get_data = request.get_json()
    token = get_data.get('token')
    enable = get_data.get('enable')

    # 验证token
    verify_result = verify_token(token, '648648')
    if verify_result == -1:
        return jsonify(code=-1, msg="无效的token")
    elif verify_result == -2:
        return jsonify(code=-2, msg="token已过期")
    elif verify_result != SuperAdmin.account:
        return jsonify(code=-3, msg="权限不足")
    # 验证通过
    else:
        users = User.query.filter_by(is_enable=enable).all()
        accounts = []
        for single_user in users:
            group = Group.query.filter_by(id=single_user.group_id).first()

            single_account = {
                "account": single_user.account,
                "password": single_user.password,
                "name": single_user.name,
                "group": group.name,
                "email": single_user.email,
                "avatars": get_img_url(single_user.account),
                "qq_number": single_user.qq_number
            }

            accounts.append(single_account)

        return jsonify(code=0, msg="获取成功", accounts=accounts)


@app.route('/api/account/adminAccounts', methods=["POST"])
def get_admins():
    get_data = request.get_json()
    token = get_data.get('token')
    enable = get_data.get('enable')

    # 验证token
    verify_result = verify_token(token, '648648')
    if verify_result == -1:
        return jsonify(code=-1, msg="无效的token")
    elif verify_result == -2:
        return jsonify(code=-2, msg="token已过期")
    elif verify_result != SuperAdmin.account:
        return jsonify(code=-3, msg="权限不足")
    # 验证通过
    else:
        admins = Member.query.filter_by(is_enable=enable).all()
        accounts = []
        for single_admin in admins:

            single_account = {
                "id": single_admin.id,
                "name": single_admin.name,
                "email": single_admin.email,
                "qq_number": single_admin.qq_number,
            }

            accounts.append(single_account)

        return jsonify(code=0, msg="获取成功", accounts=accounts)


@app.route('/api/account/adminInfoChange', methods=["POST"])
def change_admin_info():
    get_data = request.get_json()

    token = get_data.get('token')
    id = get_data.get('id')
    name = get_data.get('name')
    email = get_data.get('email')
    qq_number = get_data.get('qq_number')
    is_enable = get_data.get('enable')

    # 验证token
    verify_result = verify_token(token, '648648')
    if verify_result == -1:
        return jsonify(code=-1, msg="无效的token")
    elif verify_result == -2:
        return jsonify(code=-2, msg="token已过期")
    elif verify_result != SuperAdmin.account:
        return jsonify(code=-3, msg="权限不足")
    # 验证通过
    else:
        admin = Member.query.filter_by(id=id)
        if not admin.first():
            return jsonify(code=-4, msg="用户不存在")
        # 用户id不可修改
        admin.update({
            "name": name,
            "email": email,
            "qq_number": qq_number,
            "is_enable": is_enable
        })

        db.session.commit()
        return jsonify(code=0, msg="修改成功")