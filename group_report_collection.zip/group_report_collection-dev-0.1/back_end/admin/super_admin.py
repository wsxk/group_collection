from main import app
from model import db, Member
from jwt_utils.jwt import verify_token


def is_super_admin(token):
    account = verify_token(token, '648648')

    if account != "diangroup":
        return False
    else:
        return True
